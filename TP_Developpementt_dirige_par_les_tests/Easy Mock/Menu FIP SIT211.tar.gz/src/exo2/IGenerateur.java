package exo2;

/**
 *
 * Interface IGenerateur :  un_entier fournit un entier
 */
public interface IGenerateur {

	public abstract int un_entier();
}

